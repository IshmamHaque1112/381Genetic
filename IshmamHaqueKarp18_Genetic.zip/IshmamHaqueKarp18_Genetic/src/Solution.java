import java.util.*;
public class Solution {
  ArrayList<Integer> bitstring=new ArrayList<Integer>();
  int fitness=0;
  int weight=0;
}
