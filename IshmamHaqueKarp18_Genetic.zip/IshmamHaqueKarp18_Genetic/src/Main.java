import java.util.*;
import java.io.*;
public class Main {
	//Global values for generation
	static int maxweight=0;
	static int size=0;
	static ArrayList<Integer> objectarr = new ArrayList<>();
    static ArrayList<Integer> costarr = new ArrayList<>();
    static ArrayList<Integer> weightarr = new ArrayList<>();
    static int N;
    static int sequencenumber;
	public static void sortsolutionlist(ArrayList<Solution> sol) { //sorts solution list for each generation from best to worst
	 for(int i=0;i<sol.size()-1;i++) {
	  for(int j=i+1;j<sol.size();j++) {
		if(sol.get(j).fitness>sol.get(i).fitness) {
			Solution temp=sol.get(j);
		    sol.set(j,sol.get(i));
		    sol.set(i,temp);
		}
		else if((sol.get(j).fitness==0)&&(sol.get(i).fitness==0)) { //if both have fitness equal to 0 The one with the better bitstring takes precedent
			int sumi=0;
			int sumj=0;
			for(int a=0;a<costarr.size();a++) {
	        	int exp=(int)(Math.pow(2,costarr.size()-1-a));
	        	sumi=sumi+(exp*sol.get(i).bitstring.get(a));
	        	sumj=sumj+(exp*sol.get(j).bitstring.get(a));
	        }
			if(sumj>sumi) {
				Solution temp=sol.get(j);
			    sol.set(j,sol.get(i));
			    sol.set(i,temp);	
			}
		} 
	  }
	 }
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
        Scanner inFile1= new Scanner(new FileReader(args[0]));
		BufferedWriter outFile1=new BufferedWriter(new FileWriter(args[1]));
		outFile1.write("This is a demo knapsack problem done with genetic algorithms");
		outFile1.newLine();
		 size=Integer.parseInt(inFile1.next());
		 maxweight=Integer.parseInt(inFile1.next());
		 outFile1.write("The number of objects is "+size+" and max weight of knapsack is "+maxweight);
		 outFile1.newLine();
		 for(int i=0;i<size;i++) {
			objectarr.add(i+1); 
		 }
		 int counter1=0;
		 int counter2=0;
		 while(counter1<size) {
			int currcost=Integer.parseInt(inFile1.next());
			costarr.add(currcost);
			counter1++;
		 }
		 while(counter2<size) {
				int currweight=Integer.parseInt(inFile1.next());
				weightarr.add(currweight);
				counter2++;
		 }
		 for(int i=0;i<size;i++) {
			outFile1.write("Object "+(i+1)+" is cost "+costarr.get(i)+" and weight "+weightarr.get(i));
			outFile1.newLine();
		 } 
	  
	    outFile1.write("This method uses genetic crossover and mutation. First it generates a start set of 1000 individuals.");
	    outFile1.newLine();
	    int generations=1;
	    int bestfit=0;
	    int bestweight=0;
	    int worstfit=0;
	    int worstweight=0;
	    int totalfit=0;
	    //Solution bestsol = new Solution();
	    //Solution worstsol=new Solution();
	    ArrayList<Integer> bestarr=new ArrayList<Integer>();
	    ArrayList<Integer> worstarr=new ArrayList<Integer>();
        for(int i=0;i<costarr.size();i++) {
	     bestarr.add(0);
	     worstarr.add(0);
	    }
	   	int initsolutions=0;
	    int topowerof2=(int) Math.pow(2,costarr.size());
	    int maximum=topowerof2-1;
	    ArrayList<Solution> solutionlist=new ArrayList<Solution>();
	    int bestindex=0;
	    int worstindex=0;
	    while(initsolutions<1000) {//generates first generation similar to random
	        int rand=(int) (Math.floor(Math.random() * (maximum-0 + 1)) +0);
	        int curr=rand;
	        int currweight=0;
	        int currfit=0;
	        ArrayList<Integer> currarr=new ArrayList<Integer>();
	        for(int i=0;i<=costarr.size()-1;i++) {
	        	if(curr>=(int)(Math.pow(2,costarr.size()-1-i))) {
	        	 currarr.add(1);
	        	 curr=curr-(int)(Math.pow(2,costarr.size()-1-i));
	        	}
	        	else currarr.add(0);
	        }
	        int sum=0;
	        for(int i=0;i<costarr.size();i++) {
	        	int exp=(int)(Math.pow(2,costarr.size()-1-i));
	        	sum=sum+(exp*currarr.get(i));
	        }       
	        for(int i=0;i<costarr.size();i++) {
	        	if(currarr.get(i)==1) {
	        		currweight=currweight+weightarr.get(i);
	        		currfit=currfit+costarr.get(i);
	        	}
	        }
	        if(currweight>maxweight) {
	        	currfit=0;
	        }
	        Solution newsol=new Solution();
	        newsol.bitstring=(ArrayList<Integer>) currarr.clone();
	        newsol.fitness=currfit;
	        newsol.weight=currweight;
	        totalfit=totalfit+currfit;
	        solutionlist.add(newsol);
            initsolutions++;
	    }
	    for(int i=0;i<solutionlist.size();i++) { //getting the best solution
	    	if((solutionlist.get(i).fitness>bestfit)&&(solutionlist.get(i).weight<=maxweight)) {
	        	bestfit=solutionlist.get(i).fitness;
	        	bestweight=solutionlist.get(i).weight;
	        	bestarr=(ArrayList<Integer>)solutionlist.get(i).bitstring.clone();
	        	bestindex=i;
	        	//bestsol=solutionlist.get(i);
	        }
	        if(solutionlist.get(i).fitness<=worstfit) {// getting worst solution
	        	worstfit=solutionlist.get(i).fitness;
	        	worstweight=solutionlist.get(i).fitness;
	        	worstarr=(ArrayList<Integer>)solutionlist.get(i).bitstring.clone();
	            worstindex=i;
	            //worstsol=solutionlist.get(i);
	        }
	    }
	    outFile1.write("Best solution for Generation 1: ");
	    outFile1.write("[");
	    for(int i=0;i<bestarr.size();i++) {
          if(bestarr.get(i)==1) outFile1.write(i+1+",");
        }
	    outFile1.write("]");
	    outFile1.newLine();
	    outFile1.write("Best weight for Generation 1: "+bestweight);
	    outFile1.newLine();
	    outFile1.write("Best fitness for Generation 1: "+bestfit);
        outFile1.newLine();
        outFile1.write("Worst solution for Generation 1: ");
	    outFile1.write("[");
	    for(int i=0;i<worstarr.size();i++) {
          if(worstarr.get(i)==1) outFile1.write(i+1+",");
        }
	    outFile1.write("]");
	    outFile1.newLine();
	    outFile1.write("Worst weight for Generation 1 "+worstweight);
	    outFile1.newLine();
	    outFile1.write("Worst fitness for Generation 1 "+worstfit);
	    outFile1.newLine();	    
	    double avgfit=(double) (totalfit/1000);
	    outFile1.write("Average fitness for first generation "+avgfit);
	    outFile1.newLine();	    
	    
	    
	    
	    //System.out.println(bestsol);
	    while(generations<100) {
	    	totalfit=0;
	    	int init=1;
	    	ArrayList<Solution> newsol=new ArrayList<Solution>();
	    	Solution best=new Solution();
	    	best.bitstring=(ArrayList<Integer>) bestarr.clone();
	    	best.fitness=bestfit;
	    	best.weight=bestweight;
	    	newsol.add(best);//best solution is cloned in
	    	sortsolutionlist(solutionlist); //sorting to ensure the best only reproduce with the best
	    	ArrayList<Solution> parentlist=(ArrayList<Solution>) solutionlist.clone();
	    	while(init<1000) { //creates 999 children through crossover
	    	  Solution parent1=parentlist.get(0);
	    	  //System.out.println("Fitness " +parent1.fitness);
	    	  parentlist.remove(0);
	    	  Solution parent2=parentlist.get(0);
	    	  parentlist.remove(0);
	    	  Solution child1=new Solution();
	    	  Solution child2=new Solution();
	    	  for(int i=0;i<costarr.size();i++) {
	  	        int rand1=(int) (Math.floor(Math.random() * (1-0 + 1)) +0);
	  	        //System.out.println(init);
                if(rand1==0) { //child1 and child2 are haploid if rand equals 0 child1 gets parent1 bit, child2 gets parent. if rand equals 0 other way around
                  //System.out.println(parent1.bitstring.size());
                  child1.bitstring.add(parent1.bitstring.get(i));
                  child2.bitstring.add(parent2.bitstring.get(i));
                }
                else if(rand1==1) {
                    child1.bitstring.add(parent2.bitstring.get(i));
                    child2.bitstring.add(parent1.bitstring.get(i));
                }
                Random rand2 = new Random();
                //chance child1 and child2 get mutated is 5%
                int mutation1 = rand2.nextInt(20) + 1;
                int mutation2 = rand2.nextInt(20) + 1;
                 if(mutation1>19) {
                	int removedbit=child1.bitstring.get(i);
                	child1.bitstring.remove(i);
                	child1.bitstring.add((removedbit+1)%1);
                 }
                 if(mutation2>19) {
                 	int removedbit=child2.bitstring.get(i);
                 	child2.bitstring.remove(i);
                 	child2.bitstring.add((removedbit+1)%1);
                  }
	    	  }
	    	  for(int i=0;i<costarr.size();i++) { //computing weight and fitness
		        	if(child1.bitstring.get(i)==1) {
		        		child1.weight=child1.weight+weightarr.get(i);
		        		child1.fitness=child1.fitness+costarr.get(i);
		        	}
		        	if(child2.bitstring.get(i)==1) {
		        		child2.weight=child2.weight+weightarr.get(i);
		        		child2.fitness=child2.fitness+costarr.get(i);
		        	}
		      }
	    	  if(child1.weight>maxweight) {
		        	child1.fitness=0;
		      }
	    	  if(child2.weight>maxweight) {
		        	child2.fitness=0;
		      }
	    	  newsol.add(child1);
	    	  totalfit=totalfit+child1.fitness;
	    	  init++;
	    	  newsol.add(child2);
	    	  totalfit=totalfit+child2.fitness;
	    	  init++;
	    	}
	    	solutionlist=(ArrayList<Solution>) newsol.clone();
	    	for(int i=0;i<solutionlist.size();i++) {
	    		//System.out.println(solutionlist.size());
		    	if((solutionlist.get(i).fitness>bestfit)&&(solutionlist.get(i).weight<=maxweight)) { //best solution stored
		        	bestfit=solutionlist.get(i).fitness;
		        	bestweight=solutionlist.get(i).weight;
		        	bestarr=(ArrayList<Integer>)solutionlist.get(i).bitstring.clone();
		        	bestindex=i;
		        	//bestsol=solutionlist.get(i);
		        }
		        if(solutionlist.get(i).fitness<=worstfit) {//worst solution stored
		        	worstfit=solutionlist.get(i).fitness;
		        	worstweight=solutionlist.get(i).fitness;
		        	worstarr=(ArrayList<Integer>)solutionlist.get(i).bitstring.clone();
		            worstindex=i;
		           //worstsol=solutionlist.get(i);
		        }
		    }	    	
		    generations++;
		    if(generations==50) {
		    	outFile1.write("Best solution for Generation 50: ");
			    outFile1.write("[");
			    for(int i=0;i<bestarr.size();i++) {
		          if(bestarr.get(i)==1) outFile1.write(i+1+",");
		        }
			    outFile1.write("]");
			    outFile1.newLine();
			    outFile1.write("Best weight for Generation 50: "+bestweight);
			    outFile1.newLine();
			    outFile1.write("Best fitness for Generation 50: "+bestfit);
		        outFile1.newLine();
		        outFile1.write("Worst solution for Generation 50: ");
			    outFile1.write("[");
			    for(int i=0;i<worstarr.size();i++) {
		          if(worstarr.get(i)==1) outFile1.write(i+1+",");
		        }
			    outFile1.write("]");
			    outFile1.newLine();
			    outFile1.write("Worst weight for Generation 50 "+worstweight);
			    outFile1.newLine();
			    outFile1.write("Worst fitness for Generation 50 "+worstfit);
			    outFile1.newLine();
			    avgfit=(double) (totalfit/1000);
			    outFile1.write("Average fitness for generation 50 "+avgfit);
			    outFile1.newLine();	
		    	
		    }
	    }
	    outFile1.write("Best final solution: ");
	    outFile1.write("[");
	    for(int i=0;i<bestarr.size();i++) {
          if(bestarr.get(i)==1) outFile1.write(i+1+",");
        }
	    outFile1.write("]");
	    outFile1.newLine();
	    outFile1.write("Best final weight "+bestweight);
	    outFile1.newLine();
	    outFile1.write("Best final fitness "+bestfit);
        outFile1.newLine();
        outFile1.write("Worst final solution: ");
	    outFile1.write("[");
	    for(int i=0;i<worstarr.size();i++) {
          if(worstarr.get(i)==1) outFile1.write(i+1+",");
        }
	    outFile1.write("]");
	    outFile1.newLine();
	    outFile1.write("Worst final weight "+worstweight);
	    outFile1.newLine();
	    outFile1.write("Worst final fitness "+worstfit);
	    outFile1.newLine();
	    avgfit=(double) (totalfit/1000);
	    outFile1.write("Average fitness for last generation "+avgfit);
	    outFile1.newLine();	
	    inFile1.close();
        outFile1.close();
	}

}
