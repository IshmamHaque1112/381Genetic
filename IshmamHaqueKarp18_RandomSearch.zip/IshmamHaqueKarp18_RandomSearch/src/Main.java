import java.util.*;
import java.io.*;
public class Main {
	static int maxweight=0;
	static int size=0;
	static ArrayList<Integer> objectarr = new ArrayList<>();
    static ArrayList<Integer> costarr = new ArrayList<>();
    static ArrayList<Integer> weightarr = new ArrayList<>();
    static int N;
    static int sequencenumber;
	public static double BBS0to1() {
		double returned=0.0;
		int squared=sequencenumber*sequencenumber;
		sequencenumber=squared%N;
		if (sequencenumber<0) sequencenumber+=N;
		returned=((double)sequencenumber/(double)(N-1));
		//System.out.println(returned);
		return returned;
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
        Scanner inFile1= new Scanner(new FileReader(args[0]));
		BufferedWriter outFile1=new BufferedWriter(new FileWriter(args[1]));
		outFile1.write("This is a demo knapsack problem done with brute force. The next one is done with random search");
		outFile1.newLine();
		 size=Integer.parseInt(inFile1.next());
		 maxweight=Integer.parseInt(inFile1.next());
		 outFile1.write("The number of objects is "+size+" and max weight of knapsack is "+maxweight);
		 //System.out.println("The number of objects is "+size+" and max weight of knapsack is "+maxweight);
		 outFile1.newLine();
		 for(int i=0;i<size;i++) {
			objectarr.add(i+1); 
		 }
		 int counter1=0;
		 int counter2=0;
		 while(counter1<size) {
			//System.out.println(costarr);
			int currcost=Integer.parseInt(inFile1.next());
			costarr.add(currcost);
			counter1++;
		 }
		 while(counter2<size) {
				int currweight=Integer.parseInt(inFile1.next());
				weightarr.add(currweight);
				counter2++;
		 }
		 for(int i=0;i<size;i++) {
			outFile1.write("Object "+(i+1)+" is cost "+costarr.get(i)+" and weight "+weightarr.get(i));
			outFile1.newLine();
		 } ;
	    outFile1.write("This method uses random()");
	    outFile1.newLine();
	    int generations=0;
	    int bestfit=0;
	    int bestweight=0;
	    int worstfit=0;
	    int worstweight=0;
	    ArrayList<Integer> bestarr=new ArrayList<>();
	    ArrayList<Integer> worstarr=new ArrayList<>();
	    int totalfit=0;
	    while(generations<100) {
	    	int initsolutions=0;
		    int topowerof2=(int) Math.pow(2,costarr.size());
		    int maximum=topowerof2-1;
		    while(initsolutions<1000) {
		        int rand=(int) (Math.floor(Math.random() * (maximum-0 + 1)) +0);
		        //System.out.println(rand);
		        int curr=rand;
		        int currweight=0;
		        int currfit=0;
		        ArrayList<Integer> currarr=new ArrayList<>();
		        for(int i=0;i<=costarr.size()-1;i++) {
		        	if(curr>=(int)(Math.pow(2,costarr.size()-1-i))) {
		        	 currarr.add(1);
		        	 curr=curr-(int)(Math.pow(2,costarr.size()-1-i));
		        	}
		        	else currarr.add(0);
		        }
		        int sum=0;
		        for(int i=0;i<costarr.size();i++) {
		        	int exp=(int)(Math.pow(2,costarr.size()-1-i));
		        	sum=sum+(exp*currarr.get(i));
		        }       
		        //System.out.println(sum);
		        for(int i=0;i<costarr.size();i++) {
		        	if(currarr.get(i)==1) {
		        		currweight=currweight+weightarr.get(i);
		        		currfit=currfit+costarr.get(i);
		        	}
		        }
		        if((currfit>bestfit)&&(currweight<=maxweight)) {
		        	bestfit=currfit;
		        	bestweight=currweight;
		        	bestarr=(ArrayList<Integer>)currarr.clone();
		        }
		        if(currweight>maxweight) {
		        	currfit=0;
		        }
		        if(currfit<=worstfit) {
		        	worstfit=currfit;
		        	worstweight=currweight;
		        	worstarr=(ArrayList<Integer>)currarr.clone();
		        }
		        totalfit=currfit+totalfit;
                initsolutions++;
		    }
		    generations++;
	    }
	    outFile1.write("Best solution: ");
	    outFile1.write("[");
	    for(int i=0;i<bestarr.size();i++) {
          if(bestarr.get(i)==1) outFile1.write(i+1+",");
        }
	    outFile1.write("]");
	    outFile1.newLine();
	    outFile1.write("Best weight "+bestweight);
	    outFile1.newLine();
	    outFile1.write("Best fitness "+bestfit);
        outFile1.newLine();
        outFile1.write("Worst solution: ");
	    outFile1.write("[");
	    for(int i=0;i<worstarr.size();i++) {
          if(worstarr.get(i)==1) outFile1.write(i+1+",");
        }
	    outFile1.write("]");
	    outFile1.newLine();
	    outFile1.write("Worst weight "+worstweight);
	    outFile1.newLine();
	    outFile1.write("Worst fitness "+worstfit);
	    outFile1.newLine();
	    double avgfit=(double) (totalfit/100000);
	    outFile1.write("Average fitness "+avgfit);
	    outFile1.newLine();
	    Random rand1 = new Random(); 
        sequencenumber=Math.abs(rand1.nextInt(100000000))+1;
        Random rand2 = new Random(); 
        N=Math.abs(rand2.nextInt(100000000))+1;
        //sequencenumber=127;
        //N=5293;
	    outFile1.write("This method uses BBS.");
	    outFile1.newLine();
	    int generations1=0;
	    int bestfit1=0;
	    int bestweight1=0;
	    int worstfit1=0;
	    int worstweight1=0;
	    ArrayList<Integer> bestarr1=new ArrayList<>();
	    ArrayList<Integer> worstarr1=new ArrayList<>();
	    int totalfit1=0;
	    while(generations1<100) {
	    	int initsolutions=0;
		    int topowerof2=(int) Math.pow(2,costarr.size());
		    int maximum=topowerof2-1;
		    while(initsolutions<1000) {
		        int rand=(int) (Math.floor(BBS0to1() * (maximum-0 + 1)) +0);
		        int curr=rand;
		        int currweight=0;
		        int currfit=0;
		        ArrayList<Integer> currarr=new ArrayList<>();
		        for(int i=0;i<=costarr.size()-1;i++) {
		        	if(curr>=(int)(Math.pow(2,costarr.size()-1-i))) {
		        	 currarr.add(1);
		        	 curr=curr-(int)(Math.pow(2,costarr.size()-1-i));
		        	}
		        	else currarr.add(0);
		        }
		        for(int i=0;i<costarr.size();i++) {
		        	if(currarr.get(i)==1) {
		        		currweight=currweight+weightarr.get(i);
		        		currfit=currfit+costarr.get(i);
		        	}
		        }
		        if((currfit>bestfit1)&&(currweight<=maxweight)) {
		        	bestfit1=currfit;
		        	bestweight1=currweight;
		        	bestarr1=(ArrayList<Integer>)currarr.clone();
		        }
		        if(currweight>maxweight) {
		        	currfit=0;
		        }
		        if(currfit<=worstfit1) {
		        	worstfit1=currfit;
		        	worstweight1=currweight;
		        	worstarr1=(ArrayList<Integer>)currarr.clone();
		        }
		        totalfit1=currfit+totalfit1;
                initsolutions++;
		    }
		    generations1++;
	    }
	    outFile1.write("Best solution: ");
	    outFile1.write("[");
	    for(int i=0;i<bestarr1.size();i++) {
          if(bestarr1.get(i)==1) outFile1.write(i+1+",");
        }
	    outFile1.write("]");
	    outFile1.newLine();
	    outFile1.write("Best weight "+bestweight1);
	    outFile1.newLine();
	    outFile1.write("Best fitness "+bestfit1);
        outFile1.newLine();
        outFile1.write("Worst solution: ");
	    outFile1.write("[");
	    for(int i=0;i<worstarr1.size();i++) {
          if(worstarr1.get(i)==1) outFile1.write(i+1+",");
        }
	    outFile1.write("]");
	    outFile1.newLine();
	    outFile1.write("Worst weight "+worstweight1);
	    outFile1.newLine();
	    outFile1.write("Worst fitness "+worstfit1);
	    outFile1.newLine();
	    double avgfit1=(double) (totalfit1/100000);
	    outFile1.write("Average fitness "+avgfit1);
	    
	    
	    
	    
	    
	    
	    
	    
	    inFile1.close();
        outFile1.close();
	}

}
