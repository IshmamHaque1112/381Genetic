import java.util.*;
import java.io.*;
public class Main {
	static int maxweight=0;
	static int size=0;
	static ArrayList<Integer> objectarr = new ArrayList<>();
    static ArrayList<Integer> costarr = new ArrayList<>();
    static ArrayList<Integer> weightarr = new ArrayList<>();
	 public static void returnsubsets(ArrayList<ArrayList<Integer>> returnlist,ArrayList<Integer> storedarray,ArrayList<Integer> input,int index){
		 if(index==input.size()) {
			returnlist.add(storedarray);
			return;
		 }
		ArrayList<Integer> newarr=storedarray;
		returnsubsets(returnlist, new ArrayList<>(newarr),input,index+1);
		storedarray.add(input.get(index));
		returnsubsets(returnlist, new ArrayList<>(storedarray),input,index+1);
		
	    }
	 public static void solveKnapsack(BufferedWriter outFile) throws IOException {
		 ArrayList<ArrayList<Integer>> subsets=new ArrayList<>();
	        ArrayList<Integer> store= new ArrayList<>();
	        returnsubsets(subsets,store,objectarr,0);
	        outFile.write("max weight of knapsack is "+maxweight);
			outFile.newLine();
	        ArrayList<Integer> finalarray=new ArrayList<>();
	        int finalweight=0;
	        int finalvalue=0;
	        for(int i=0;i<subsets.size();i++) {
	        	int cost=0;
	        	int weight=0;
	        	for(int j=0;j<subsets.get(i).size();j++) {
	        	  cost=cost+costarr.get(subsets.get(i).get(j)-1);
	        	  weight=weight+weightarr.get(subsets.get(i).get(j)-1);
	        	  if((cost>finalvalue)&&(weight<=maxweight)) {
	        		  finalvalue=cost;
	        		  finalweight=weight;
	        		  finalarray=subsets.get(i);
	        	 }
	           }
	        }
	        outFile.write("The best item array to pick is "+finalarray);
	        outFile.newLine();
	        outFile.write("Final value "+finalvalue+" Final weight "+finalweight);
	        outFile.newLine();
	 }
	 public static void loadAry(Scanner inFile,BufferedWriter outFile) throws IOException {
		 size=Integer.parseInt(inFile.next());
		 maxweight=Integer.parseInt(inFile.next());
		 outFile.write("The number of objects is "+size+" and max weight of knapsack is "+maxweight);
		 outFile.newLine();
		 int counter1=0;
		 int counter2=0;
		 while(counter1<size) {
			int currcost=Integer.parseInt(inFile.next());
			costarr.add(currcost);
			counter1++;
		 }
		 while(counter2<size) {
				int currweight=Integer.parseInt(inFile.next());
				weightarr.add(currweight);
				counter2++;
		 }
		 for(int i=0;i<size;i++) {
			outFile.write("Object "+(i+1)+" is cost "+costarr.get(i)+" and weight "+weightarr.get(i));
			outFile.newLine();
		 }
	 }
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
        Scanner inFile1= new Scanner(new FileReader(args[0]));
		BufferedWriter outFile1=new BufferedWriter(new FileWriter(args[1]));
		outFile1.write("This is a demo knapsack problem done with brute force.");
		outFile1.newLine();
		 size=Integer.parseInt(inFile1.next());
		 maxweight=Integer.parseInt(inFile1.next());
		 outFile1.write("The number of objects is "+size+" and max weight of knapsack is "+maxweight);
		 //System.out.println("The number of objects is "+size+" and max weight of knapsack is "+maxweight);
		 outFile1.newLine();
		 for(int i=0;i<size;i++) {
			objectarr.add(i+1); 
		 }
		 int counter1=0;
		 int counter2=0;
		 while(counter1<size) {
			//System.out.println(costarr);
			int currcost=Integer.parseInt(inFile1.next());
			costarr.add(currcost);
			counter1++;
		 }
		 while(counter2<size) {
				int currweight=Integer.parseInt(inFile1.next());
				weightarr.add(currweight);
				counter2++;
		 }
		 for(int i=0;i<size;i++) {
			outFile1.write("Object "+(i+1)+" is cost "+costarr.get(i)+" and weight "+weightarr.get(i));
			outFile1.newLine();
		 } 
		 //System.out.println(costarr);
		 //System.out.println(weightarr);
		 ArrayList<ArrayList<Integer>> subsets=new ArrayList<>();
	     ArrayList<Integer> store= new ArrayList<>();
	     returnsubsets(subsets,store,objectarr,0);
	     ArrayList<Integer> finalarray=new ArrayList<>();
	        int finalweight=0;
	        int finalvalue=0;
	        for(int i=0;i<subsets.size();i++) {
	        	int cost=0;
	        	int weight=0;
	        	for(int j=0;j<subsets.get(i).size();j++) {
	        	  cost=cost+costarr.get(subsets.get(i).get(j)-1);
	        	  weight=weight+weightarr.get(subsets.get(i).get(j)-1);
	        	  if((cost>finalvalue)&&(weight<=maxweight)) {
	        		  finalvalue=cost;
	        		  finalweight=weight;
	        		  finalarray=subsets.get(i);
	        	 }
	           }
	        }
	        outFile1.write("The best item array to pick is "+finalarray);
	        outFile1.newLine();
	        outFile1.write("Final value "+finalvalue+" Final weight "+finalweight);
	        outFile1.newLine();
        inFile1.close();
        outFile1.close();
	}

}
